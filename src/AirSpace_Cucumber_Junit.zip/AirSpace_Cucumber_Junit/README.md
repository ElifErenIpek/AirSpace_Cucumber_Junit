# AirSpace 

Cucumber Junit FrameWork


In this framework we use 

SELENIUM => is a collection of jar files. The jar files have Classes. And these classes have ready to use methods. 

- In order to be able to use Selenium, you need to download Selenium jar files.
	1- First way of downloading Selenium is from SeleniumHQ (official website of Selenium)
	2- Second way is to create a maven project, and add dependencies(jar files) into the project. Maven will the download files for us.

Use Java programming language
Gerkin language

== Install

=== IntelliJ 12 and above
=== install selenium 


== Creating Tests for:

=== MainTestEmployee
=== MainTestManger


=== Using dependencies
Selenium 
Bonigarcia 
Maven tool
TestNG
JUnit
Cucumber



=== configuration.properties
browser = chrome
inventoryUrl=http://app.briteerp.com/web/login

managerUsername=in@info.com
managerPassword=alsfuh7we67

employeeUsername=in3@info.com
employeePassword=alsfuh7we72
== Selenium Setup


Download the latest version of selenium grid from http://seleniumhq.org/download/
===Using a Custom Selenium Server 'java --jar /path/to/your/customer/selenium-server.jar'



